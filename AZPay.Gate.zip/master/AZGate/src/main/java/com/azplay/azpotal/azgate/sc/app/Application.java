/**
 * 
 */
package com.azplay.azpotal.azgate.sc.app;

/**
 * @author thang
 *
 */
public class Application {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new Server();
	}

}
