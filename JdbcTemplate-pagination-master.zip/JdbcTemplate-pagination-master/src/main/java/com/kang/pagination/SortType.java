package com.kang.pagination;

/**
 * Created by Administrator on 2016/8/29.
 */
public enum  SortType {
    ASC,
    DESC;
}
