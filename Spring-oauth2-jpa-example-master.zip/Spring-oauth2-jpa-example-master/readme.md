# Spring-oauth2-jpa-example
A simple and basic example  to secure REST APsI with authentication using Spring Boot , Security , OAuth2 and JPA.

You can find more about this topic on official spring documentation:

https://projects.spring.io/spring-security-oauth/docs/oauth2.html