# spring-security

Demo project for Spring Security:
- Login
- Logout
- Authorizing

using:

- Spring Boot
- Spring Security
- Spring MVC
- Spring Data JPA
- Thymeleaf
