# Demo for pagination with Thymeleaf template engine

## How to run

Run `mvn install` in root directory

Run `java -jar target/spring-thymeleaf-pagination-0.0.1-SNAPSHOT.jar`

Go to http://localhost:8080

Special thanks to [Bruno Raljic](https://github.com/brunoraljic) for implementation of algorithm that calculates button span.