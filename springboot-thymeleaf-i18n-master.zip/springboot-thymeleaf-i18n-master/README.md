# springboot-thymeleaf-i18n

An example of how to i18n with Spring Boot and Thymeleaf (the most mininalist way) ;)

Original post at: http://www.marcelustrojahn.com/2016/12/springboot-thymeleaf-i18n-internationalization/
